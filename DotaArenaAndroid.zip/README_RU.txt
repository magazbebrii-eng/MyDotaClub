DOTA ARENA — Android Studio проект

Что внутри:
- app/src/main/assets/index.html — твоя текущая версия Dota Arena.
- WebView-оболочка для запуска HTML-игры как Android-приложения.
- JavaScript и DOM Storage включены, чтобы работали игровые скрипты и локальные сохранения.

Как получить APK:
1. Установи Android Studio.
2. Распакуй архив DotaArenaAndroid.zip.
3. В Android Studio выбери Open и укажи папку DotaArenaAndroid.
4. Дождись окончания Sync/загрузки компонентов Gradle.
5. Открой Build -> Build Bundle(s) / APK(s) -> Build APK(s).
6. После сборки нажми locate в уведомлении Android Studio.
   Обычно APK находится в app/build/outputs/apk/debug/app-debug.apk.
7. Перенеси app-debug.apk на телефон и установи. На телефоне может понадобиться разрешить установку приложений из этого источника.

Важно:
- Для сборки нужен Android Studio и Android SDK (API 35), JDK 17.
- Это проект для создания APK, сам APK здесь не собран.
- В HTML есть внешняя ссылка на Google Fonts и Twitch; для них нужен интернет.
- Привязка к устройству пока локальная внутри приложения/браузерного хранилища. Для настоящего аккаунта с серверной авторизацией и синхронизацией прогресса понадобится backend и база данных.
- Для публикации в Google Play потребуется отдельная release-сборка и подпись ключом.
